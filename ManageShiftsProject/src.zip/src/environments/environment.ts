export const environment = {
  firebase: {
    projectId: 'manageshifts-2277a',
    appId: '1:910963039268:web:1a819983354d2d93a60cb1',
    storageBucket: 'manageshifts-2277a.appspot.com',
    locationId: 'europe-west',
    apiKey: 'AIzaSyBSEFNuA_S-XOa2diJgLwCDaqRY2QANBto',
    authDomain: 'manageshifts-2277a.firebaseapp.com',
    messagingSenderId: '910963039268',
    measurementId: 'G-RWBYVRG2W3',
  },
    firebaseConfig : {
        apiKey: "AIzaSyBSEFNuA_S-XOa2diJgLwCDaqRY2QANBto",
        authDomain: "manageshifts-2277a.firebaseapp.com",
        projectId: "manageshifts-2277a",
        storageBucket: "manageshifts-2277a.appspot.com",
        messagingSenderId: "910963039268",
        appId: "1:910963039268:web:1a819983354d2d93a60cb1",
        measurementId: "G-RWBYVRG2W3"
      }
}
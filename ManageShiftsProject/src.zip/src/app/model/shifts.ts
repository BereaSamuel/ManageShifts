export interface Shift {
  firstName: string;
  lastName: string;
  id: string;
  date: string;
  startTime: string;
  endTime: string;
  shiftPlace: string;
  wage: string;
  comment: string;
  userId: string;
  totalEarnings: string;
}

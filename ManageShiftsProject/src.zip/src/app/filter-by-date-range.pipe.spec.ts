import { FilterByDateRangePipe } from './filter-by-date-range.pipe';

describe('FilterByDateRangePipe', () => {
  it('create an instance', () => {
    const pipe = new FilterByDateRangePipe();
    expect(pipe).toBeTruthy();
  });
});
